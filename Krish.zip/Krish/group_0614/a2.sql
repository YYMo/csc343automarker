
BEGIN;

DROP SCHEMA IF EXISTS A2 CASCADE;
CREATE SCHEMA A2;
SET search_path TO A2;

--DROP TABLE IF EXISTS country CASCADE;
--DROP TABLE IF EXISTS language CASCADE;
--DROP TABLE IF EXISTS religion CASCADE;
--DROP TABLE IF EXISTS hdi CASCADE;
--DROP TABLE IF EXISTS ocean CASCADE;
--DROP TABLE IF EXISTS neighbour CASCADE;
--DROP TABLE IF EXISTS oceanAccess CASCADE;
--DROP TABLE IF EXISTS Query1 CASCADE;
--DROP TABLE IF EXISTS Query2 CASCADE;
--DROP TABLE IF EXISTS Query3 CASCADE;
--DROP TABLE IF EXISTS Query4 CASCADE;
--DROP TABLE IF EXISTS Query5 CASCADE;
--DROP TABLE IF EXISTS Query6 CASCADE;
--DROP TABLE IF EXISTS Query7 CASCADE;
--DROP TABLE IF EXISTS Query8 CASCADE;
--DROP TABLE IF EXISTS Query9 CASCADE;
--DROP TABLE IF EXISTS Query10 CASCADE;


-- The country table contains all the countries in the world and their facts.
-- 'cid' is the id of the country.
-- 'name' is the name of the country.
-- 'height' is the highest elevation point of the country.
-- 'population' is the population of the country.
CREATE TABLE country (
    cid 		INTEGER 	PRIMARY KEY,
    cname 		VARCHAR(20)	NOT NULL,
    height 		INTEGER 	NOT NULL,
    population		INTEGER 	NOT NULL);

-- The language table contains information about the languages and the percentage of the speakers of the language for each country.
-- 'cid' is the id of the country.
-- 'lid' is the id of the language.
-- 'lname' is the name of the language.
-- 'lpercentage' is the percentage of the population in the country who speak the language.
CREATE TABLE language (
    cid 		INTEGER 	REFERENCES country(cid) ON DELETE 										RESTRICT,
    lid 		INTEGER 	NOT NULL,
    lname 		VARCHAR(20) NOT NULL,
    lpercentage	REAL 		NOT NULL,
	PRIMARY KEY(cid, lid));

-- The religion table contains information about the religions and the percentage of the population in each country that follow the religion.
-- 'cid' is the id of the country.
-- 'rid' is the id of the religion.
-- 'rname' is the name of the religion.
-- 'rpercentage' is the percentage of the population in the country who follows the religion.
CREATE TABLE religion (
    cid 		INTEGER 	REFERENCES country(cid) ON DELETE 										RESTRICT,
    rid 		INTEGER 	NOT NULL,
    rname 		VARCHAR(20) 	NOT NULL,
    rpercentage		REAL 		NOT NULL,
					PRIMARY KEY(cid, rid));

-- The hdi table contains the human development index of each country per year. (http://en.wikipedia.org/wiki/Human_Development_Index)
-- 'cid' is the id of the country.
-- 'year' is the year when the hdi score has been estimated.
-- 'hdi_score' is the Human Development Index score of the country that year. It takes values [0, 1] with a larger number representing a higher HDI.
CREATE TABLE hdi (
    cid 		INTEGER 	REFERENCES country(cid) ON DELETE RESTRICT,
    year 		INTEGER 	NOT NULL,
    hdi_score 		REAL 		NOT NULL,
					PRIMARY KEY(cid, year));

-- The ocean table contains information about oceans on the earth.
-- 'oid' is the id of the ocean.
-- 'oname' is the name of the ocean.
-- 'depth' is the depth of the deepest part of the ocean (expressed as a positive integer)
CREATE TABLE ocean (
    oid 		INTEGER 	PRIMARY KEY,
    oname 		VARCHAR(20) NOT NULL,
    depth		INTEGER 	NOT NULL);

-- The neighbour table provides information about the countries and their neighbours.
-- 'country' refers to the cid of the first country.
-- 'neighbor' refers to the cid of a country that is neighbouring the first country.
-- 'length' is the length of the border between the two neighbouring countries.
-- Note that if A and B are neighbours, then there two tuples are stored in the table
-- to represent that information (A, B) and (B, A).
CREATE TABLE neighbour (
    country 	INTEGER 	REFERENCES country(cid) ON DELETE RESTRICT,
    neighbor 	INTEGER 	REFERENCES country(cid) ON DELETE RESTRICT,
    length 			INTEGER 	NOT NULL,
	PRIMARY KEY(country, neighbor));

-- The oceanAccess table provides information about the countries
-- which have a border with an ocean.
-- 'cid' refers to the cid of the country.
-- 'oid' refers to the oid of the ocean.
CREATE TABLE oceanAccess (
    cid 	INTEGER 	REFERENCES country(cid) ON DELETE RESTRICT,
    oid 	INTEGER 	REFERENCES ocean(oid) ON DELETE RESTRICT,
    PRIMARY KEY(cid, oid));


-- The following tables will be used to store the results of your queries.
-- Each of them should be populated by your last SQL statement that looks like:
-- "INSERT INTO QueryX (SELECT ...<complete your SQL query here> ... )"

CREATE TABLE Query1(
	c1id	INTEGER,
    c1name	VARCHAR(20),
	c2id	INTEGER,
    c2name	VARCHAR(20)
);

CREATE TABLE Query2(
	cid		INTEGER,
    cname	VARCHAR(20)
);

CREATE TABLE Query3(
	c1id	INTEGER,
    c1name	VARCHAR(20),
	c2id	INTEGER,
    c2name	VARCHAR(20)
);

CREATE TABLE Query4(
	cname	VARCHAR(20),
    oname	VARCHAR(20)
);

CREATE TABLE Query5(
	cid		INTEGER,
    cname	VARCHAR(20),
	avghdi	REAL
);

CREATE TABLE Query6(
	cid		INTEGER,
    cname	VARCHAR(20)
);

CREATE TABLE Query7(
	rid			INTEGER,
    rname		VARCHAR(20),
	followers	INTEGER
);

CREATE TABLE Query8(
	c1name	VARCHAR(20),
    c2name	VARCHAR(20),
	lname	VARCHAR(20)
);

CREATE TABLE Query9(
    cname		VARCHAR(20),
	totalspan	INTEGER
);

CREATE TABLE Query10(
    cname			VARCHAR(20),
	borderslength	INTEGER
);

-- Add below your SQL statements.
-- You can create intermediate views (as needed). Remember to drop these views after you have populated the result tables.
-- You can use the "\i a2.sql" command in psql to execute the SQL commands in this file.

-- Query 1 statements
create view b as select * from country join neighbour on cid = neighbor;

insert into Query1 (select country.cid, country.cname,  b.cid, b.cname from
  country, b where b.cname != country.cname and country.cid = b.country and
   b.height in (select max(b.height) from country, b where b.cname !=
    country.cname and country.cid = b.country group by country.cid));

drop view b cascade;

-- Query 2 statements
create view a as select country.cid from oceanAccess join country on
   oceanAccess.cid = country.cid;
create view b as select cid from country;
create view c as select * from b EXCEPT select * from a;
insert into Query2 (select c.cid, country.cname from c join country on
   c.cid = country.cid order by country.cname);

drop view a, b, c cascade;

-- Query 3 statements
create view a as select country.cid from oceanAccess join country on
   oceanAccess.cid = country.cid;
create view b as select cid from country;
create view c as select * from b EXCEPT select * from a;
create view landlockedcountries as select c.cid, country.cname from c join
   country on c.cid = country.cid;
--select * from landlockedcountries join neighbour on landlockedcountries.cid
-- = neighbour.country;
create view landlockedneighbors as select * from landlockedcountries join
  neighbour on landlockedcountries.cid = neighbour.country;
create view result as select cid, cname, count(neighbor) from
   landlockedneighbors group by cid, cname having count(neighbor) < 2;
create view result2 as select * from result join neighbour on result.cid
   = neighbour.country;

insert into Query3 (select country.cid, result2.cname, result2.cid as
   neighbor, country.cname from result2 join country on result2.neighbor
    = country.cid);

drop view a, b, c, landlockedcountries, landlockedneighbors, result, result2 cascade;

-- Query 4 statements
--Result A:
create view oceans as select ocean.oid, ocean.oname, oceanAccess.cid from
   ocean join oceanAccess on ocean.oid = oceanAccess.oid;
create view resultA as select oceans.oid, country.cname from oceans join
   country on oceans.cid = country.cid;
create view resultD as select resultA.cname, ocean.oname from resultA join
   ocean on resultA.oid = ocean.oid;

--Result B:

create view b as select * from neighbour join oceans on neighbour.neighbor
   = oceans.cid;

create view resultB as select country.cname, b.oname from country join b on
   b.country = country.cid;

--final result:
create view finalResult as select * from resultD UNION select * from resultB;

insert into Query4 (select * from finalResult order by cname, oname desc);

drop view oceans, resultA, resultD, b, resultB cascade;

-- Query 5 statements

--select country.cid, hdi.year, hdi.hdi_score from country join hdi on hdi.cid = country.cid;

create view a as select country.cid, hdi.year, hdi.hdi_score from country join
   hdi on hdi.cid = country.cid where hdi.year >= 2009 and hdi.year <= 2013;

create view b as select cid, avg(hdi_score) from a group by cid;

create view c as select * from b limit 10;

insert into Query5 (select c.cid, country.cname, c.avg from country join c on
   country.cid = c.cid order by avg desc);

drop view a, b, c cascade;


-- Query 6 statements
create or replace view table1 as select a.cid from hdi a, hdi b, hdi c, hdi d,
  hdi e where a.cid = b.cid and a.cid = c.cid and a.cid = d.cid and a.cid =
   e.cid and a.year between 2009 and 2013 and b.year between 2009 and 2013 and
    c.year between 2009 and 2013 and d.year between 2009 and 2013 and e.year
     between 2009 and 2013 and a.year < b.year and b.year < c.year and c.year
      < d.year and d.year < e.year and a.hdi_score < b.hdi_score and
       b.hdi_score < c.hdi_score and c.hdi_score < d.hdi_score and
        d.hdi_score < e.hdi_score;

insert into Query6 (select country.cid as cid, cname from country join table1
   on country.cid = table1.cid order by cname asc);

drop view table1;

-- Query 7 statements
create or replace view table1 as select cname, rid, rname, (rpercentage
   * population)/100 as follow from country join religion on country.cid
    = religion.cid;

create or replace view table2 as select rname, sum(follow) as followers
   from table1 group by rname;

insert into Query7 (select distinct table1.rid as rid, table2.rname as rname, table2.followers
 from table2 join table1 on table2.rname = table1.rname order by followers desc);

drop view table1, table2 cascade;

-- Query 8 statements
create or replace view table2 as select country.cid, cname, lname, (population
  * lpercentage)/100 as tpopulation from country join language on country.cid
   = language.cid;

create or replace view table3 as select table2.cid, cname, lname, neighbor,
   tpopulation from table2 join neighbour on cid = country;

create or replace view table4 as select table2.cid, cname, lname, neighbor,
   tpopulation from table2 join neighbour on cid = neighbor;

insert into Query8 (select table3.cname as c1name, table4.cname as c2name, table3.lname as lname
 from table3 join table4 on table3.neighbor = table4.neighbor and
 table3.tpopulation = table4.tpopulation order by lname ASC, c1name DESC);

drop view table2, table3, table4 cascade;

-- Query 9 statements
create view oceans as select ocean.oid, ocean.oname, oceanAccess.cid from ocean
   join oceanAccess on ocean.oid = oceanAccess.oid;

create view resultA as select oceans.oid, country.cname from oceans join country
   on oceans.cid = country.cid;

create view resultE as select resultA.cname, ocean.oname, ocean.depth from
   resultA join ocean on resultA.oid = ocean.oid;

create view resultD as select cname, max(depth) from resultE group by cname;

create view countriesOceanAccess as select distinct cname from resultA;

create view resultL as select resultD.cname, resultD.max, country.height from
   resultD join country on resultD.cname = country.cname;

create view countriesNoOceanAccess as select cname from country where cname
   not in(select * from countriesOceanAccess);


create view zero as select countriesNoOceanAccess.cname, 0 as max,
   country.height from countriesNoOceanAccess join country on country.cname
    = countriesNoOceanAccess.cname;

--combine:
create view semiResult as select * from zero union select * from resultL;

--result:
create view result as select semiResult.cname, semiResult.height+semiResult.max
   as Difference from semiResult;

insert into Query9 (select cname, difference from result where difference
   >= All (select max(difference) from result));

drop view oceans, resultA, resultE, resultD, countriesOceanAccess, resultL, countriesNoOceanAccess, zero, semiResult, result cascade;
-- Query 10 statements
create view semiResult as select * from country join neighbour on country.cid = neighbour.country;

create view resultA as select semiResult.cname, sum(semiResult.length) as totallength from semiResult group by semiResult.cname;

insert into Query10 (select cname, totallength from resultA where totallength >= All (select max(totallength) from resultA));

drop view semiResult, resultA cascade;

COMMIT;
